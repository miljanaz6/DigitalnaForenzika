using MathNet.Numerics.IntegralTransforms;
using System.Drawing.Imaging;
using System.Numerics;

namespace FFTSteganografija
{
    public partial class Form1 : Form
    {
        private Bitmap coverBitmap;
        private Bitmap secretBitmap;
        private Bitmap resultBitmap;
        private double alpha = 0.5; // Default factor
        public Form1()
        {
            InitializeComponent();
            trackBar1.Minimum = 0;
            trackBar1.Maximum = 100;
            trackBar1.Value = (int)(alpha * 100); // Set initial trackbar value
            trackBar1.TickFrequency = 10;
            trackBar1.ValueChanged += TrackBarFactor_ValueChanged;
            label1.Text = $"Faktor modifikacije: {alpha:F2}";
            button1.Text = "Izaberite Cover sliku";
            button2.Text = "Izaberite skrivenu sliku";
        }
        private void TrackBarFactor_ValueChanged(object sender, EventArgs e)
        {
            alpha = trackBar1.Value / 100.0;
            label1.Text = $"Faktor modifikacije: {alpha:F2}"; // Update label with new value
            btnApplyFFT_Click(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                coverBitmap = new Bitmap(ofd.FileName);
                pictureBox1.Image = coverBitmap;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                secretBitmap = new Bitmap(ofd.FileName);
                pictureBox2.Image = secretBitmap;
            }
        }

        private void btnApplyFFT_Click(object sender, EventArgs e)
        {
            if (coverBitmap == null || secretBitmap == null)
            {
                MessageBox.Show("Please load both cover and secret images.");
                return;
            }

            resultBitmap = ProcessImages(coverBitmap, secretBitmap, alpha);
            pictureBox2.Image = resultBitmap;
        }

        private Bitmap ProcessImages(Bitmap coverBitmap, Bitmap secretBitmap, double alpha)
        {
            var coverArray = BitmapToComplexArray(coverBitmap);
            var secretArray = BitmapToComplexArray(secretBitmap);

            var coverFFT = (Complex[])coverArray.Clone();
            var secretFFT = (Complex[])secretArray.Clone();

            Fourier.Forward(coverFFT, FourierOptions.Matlab);
            Fourier.Forward(secretFFT, FourierOptions.Matlab);

            var resultFFT = new Complex[coverFFT.Length];
            for (int i = 0; i < coverFFT.Length; i++)
            {
                resultFFT[i] = coverFFT[i] + alpha * secretFFT[i];
            }

            Fourier.Inverse(resultFFT, FourierOptions.Matlab);
            var resultArray = ComplexArrayToBitmap(resultFFT);
            return DoubleArrayToBitmap(resultArray, coverBitmap.Width, coverBitmap.Height);
        }

        private Complex[] BitmapToComplexArray(Bitmap bitmap)
        {
            var width = bitmap.Width;
            var height = bitmap.Height;
            var array = new Complex[width * height];

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    var pixel = bitmap.GetPixel(x, y);
                    double value = pixel.R; 
                    array[y * width + x] = new Complex(value, 0);
                }
            }

            return array;
        }

        private Bitmap DoubleArrayToBitmap(double[] array, int width, int height)
        {
            var bitmap = new Bitmap(width, height, PixelFormat.Format24bppRgb);

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    var value = (int)Math.Clamp(array[y * width + x], 0, 255);
                    var color = Color.FromArgb(value, value, value);
                    bitmap.SetPixel(x, y, color);
                }
            }

            return bitmap;
        }

        private double[] ComplexArrayToBitmap(Complex[] array)
        {
            var doubleArray = new double[array.Length];

            for (int i = 0; i < array.Length; i++)
            {
                doubleArray[i] = Math.Clamp(array[i].Real, 0, 255);
            }

            return doubleArray;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                coverBitmap = new Bitmap(ofd.FileName);
                pictureBox1.Image = coverBitmap;
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                secretBitmap = new Bitmap(ofd.FileName);
                pictureBox2.Image = secretBitmap;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (coverBitmap == null || secretBitmap == null)
            {
                MessageBox.Show("Please load both cover and secret images.");
                return;
            }

            var resultBitmap = ProcessImages(coverBitmap, secretBitmap, alpha);
            pictureBox2.Image = resultBitmap;
        }
        public Bitmap ExtractImageFromImage(Bitmap coverBitmap, Bitmap modifiedBitmap, double alpha)
        {
            var coverArray = BitmapToComplexArray(coverBitmap);
            var modifiedArray = BitmapToComplexArray(modifiedBitmap);

            var coverFFT = (Complex[])coverArray.Clone();
            var modifiedFFT = (Complex[])modifiedArray.Clone();

            Fourier.Forward(coverFFT, FourierOptions.Matlab);
            Fourier.Forward(modifiedFFT, FourierOptions.Matlab);

            // Ekstrakcija skrivene slike
            var secretFFT = new Complex[coverFFT.Length];
            for (int i = 0; i < coverFFT.Length; i++)
            {
                secretFFT[i] = (modifiedFFT[i] - coverFFT[i]) / alpha;
            }

            Fourier.Inverse(secretFFT, FourierOptions.Matlab);

            var extractedArray = ComplexArrayToBitmap(secretFFT);
            return DoubleArrayToBitmap(extractedArray, coverBitmap.Width, coverBitmap.Height);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = ExtractImageFromImage(coverBitmap, resultBitmap, alpha);
        }
    }
}
